you can download the entire STL folder by clicking [HERE](https://download-directory.github.io/?url=https%3A%2F%2Fgithub.com%2FVoronDesign%2FVoron-2%2Ftree%2FVoron2.4%2FSTLs)

This printer uses the StealthBurner toolhead, which is compatible with several of the printers in the Voron lineup. 
To keep things organized, StealthBurner’s files are maintained separately. 
the Stealthburner STL's can be downloaded by clicking [HERE](https://download-directory.github.io/?url=https%3A%2F%2Fgithub.com%2FVoronDesign%2FVoron-Stealthburner%2Ftree%2Fmain%2FSTLs)
